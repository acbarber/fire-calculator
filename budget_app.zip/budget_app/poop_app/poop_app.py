from flask import Flask, render_template, redirect, request, send_file, make_response, url_for
import pandas as pd
import matplotlib.pyplot as plt
import io
from poop_form import PoopForm


app = Flask(__name__)
# app.config.from_object('config.Config')

import os
SECRET_KEY = os.urandom(32)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 1



@app.route("/", methods =['POST','GET'])
def index():
    form = PoopForm()

    if request.method == 'POST':

        if form.poop.data == 'poop':
            p = ['poop'] *2000
        elif form.poop.data == 'not poop':
            p = "You don't gotta poop, man"
        else:
            p = "I don't know if you have to poop, bro!"
        return render_template('index.html',form = form,p = p)




    return render_template('index.html',form=form)



if __name__ == "__main__":
        app.run(debug=True)
