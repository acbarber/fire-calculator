from flask_wtf import FlaskForm
from wtforms import IntegerField, SubmitField, StringField, SelectField
from wtforms.validators import DataRequired, Length

class PoopForm(FlaskForm):
    poop_list = [('poop','poop'),('not poop','not poop')]
    poop = SelectField(label='Do you have to poop?',choices = poop_list)
    submit = SubmitField('Submit')
